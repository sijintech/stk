import os
from vtk import *

"""
Created on Tue Jun 23 23:27:04 2015

@author: cxx

@var string filename
@var int background1

"""
# 获取当前脚本所在目录的路径
this_dir = os.path.dirname(os.path.abspath(__file__))

# 构造VTK数据文件的完整路径
filename = "heat.eleCurr1.vtk"
vtk_path = os.path.join(this_dir, "heat.eleCurr1.vtk")

# 创建一个vtkDataSetReader对象，用于读取VTK数据文件
reader = vtkDataSetReader()
# 设置vtkDataSetReader对象要读取的文件名为vtk_path
reader.SetFileName(vtk_path)
# 更新vtkDataSetReader对象
reader.Update()

# 创建一个vtkSmartVolumeMapper对象，用于将数据映射到体积图上
mapper = vtkSmartVolumeMapper()
# 将vtkDataSetReader对象的输出连接到vtkSmartVolumeMapper对象的输入端口
mapper.SetInputConnection(reader.GetOutputPort())

# 创建一个vtkVolume对象，用于表示体积数据的可视化对象
actor = vtkVolume()
# 设置vtkVolume对象的映射器为之前创建的vtkSmartVolumeMapper对象
actor.SetMapper(mapper)

# 创建一个vtkRenderer对象，用于渲染可视化场景
renderer = vtkRenderer()
# 将vtkVolume对象添加到vtkRenderer对象中
renderer.AddActor(actor)
# 设置vtkRenderer对象的背景颜色为白色
background1 = 3
renderer.SetBackground(background1, 1, 1)

# 创建一个vtkRenderWindow对象，用于显示vtkRenderer中的内容
renderer_window = vtkRenderWindow()
# 将vtkRenderer对象添加到vtkRenderWindow对象中
renderer_window.AddRenderer(renderer)

# 创建一个vtkRenderWindowInteractor对象，用于与用户交互
interactor = vtkRenderWindowInteractor()
# 将vtkRenderWindow对象设置为vtkRenderWindowInteractor对象的渲染窗口
interactor.SetRenderWindow(renderer_window)

# 初始化vtkRenderWindowInteractor对象
interactor.Initialize()
# 启动交互式渲染
interactor.Start()
