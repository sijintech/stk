## 如何运行
    直接运行./src/main.py文件
## 如何打包
    如果想要带终端窗口，先设置main.spec文件里面的console=True，然后再运行 `$ pyinstaller .\src\main.spec`,或者运行 `$ pyinstaller .\src\main.py`
    如果不想要带终端窗口，先设置main.spec文件里面的console=False，然后再运行 `$ pyinstaller .\src\main.spec`,或者运行 `$ pyinstaller -w .\src\main.py`

    
PyPI recovery codes
5c1f95163e31da91
0c2b9e2f8c5bd416
ab0d7b96835824c7
2960fbfd49a5f241
9a0dac3ca8e0d796
8f0d52ed531b242e
1b6ba8fcb4e6896b
8bdb5da3a148d584



pypi-AgENdGVzdC5weXBpLm9yZwIkMTEzMmQ1YjMtZTc2OC00NDYxLWEyMTctMGNhZmE3MmY2NjQ1AAIqWzMsIjA1ZjIwYmEyLTJiZGMtNDdmYS04NWVjLWRhNDlhMzI5NGIxYiJdAAAGIGThEi8OUpHKca9GM5yCne4qnVY6kY8obUjS9VfxN8Mn